$(document).ready(function() {

	const $pagination = $('#messagesPagination');
	let searchQuery = '';

	$pagination.twbsPagination(defaultOpts);

	this.filterMessagesByName = function() {
		searchQuery = $('#searchMessagesInput').val();
		fetchMessages(0, defaultPageSize, searchQuery);
	}

	this.fetchMessages = function(page = 0, size = defaultPageSize, name = '') {
		Http.get(`${domain}/admin/api/messages?type=filter&page=${page}&size=${size}&name=${name}`)
			.then(res => {
				let tableContent = '';
				$('#messagesTableBody').empty();
				$pagination.twbsPagination('destroy');

				if (!res.success || res.data.totalRecord === 0) {
					$('#messagesTableBody').append(`<tr><td colspan='7' style='text-align: center;'>No Data</td></tr>`);
					return;
				}

				res.data.records.forEach(record => {
					tableContent += `<tr>
            <td>${record.id}</td>
            <td>${record.subject || ''}</td>
            <td>${record.email || ''}</td>
            <td>${moment(record.createdDate, "YYYY-MM-DD HH:mm:ss").fromNow()}</td>
            <td><span class='badge ${record.status.toLowerCase() === 'active' ? 'bg-success' : 'bg-danger'}'>${record.status}</span></td>
            <td>${record.message || ''}</td>
            <td class='text-right'>
              <a class='btn btn-danger btn-sm' onclick='removeMessage(${record.id})'>
                <i class='fas fa-trash'></i>
              </a>
            </td>
          </tr>`;
				});

				$pagination.twbsPagination($.extend({}, defaultOpts, {
					startPage: res.data.page + 1,
					totalPages: Math.ceil(res.data.totalRecord / res.data.size)
				})).on('page', (event, num) => {
					fetchMessages(num - 1, defaultPageSize, searchQuery);
				});

				$('#messagesTableBody').append(tableContent);
			})
			.catch(err => {
				toastr.error(err.errMsg);
			})
	}

	this.removeMessage = function(id) {
		if (confirm("Are you sure you want to delete this message?")) {
			Http.delete(`${domain}/admin/api/messages?id=${id}`)
				.then(res => {
					if (res.success) {
						toggleView(true);
						toastr.success('Message deleted successfully!');
					} else {
						toastr.error(res.errMsg);
					}
				})
				.catch(err => {
					toastr.error(err.errMsg);
				})
		} else {
			toastr.info('Delete action canceled.');
		}
	}

	this.getMessageById = function(id) {
		Http.get(`${domain}/admin/api/messages?type=getOne&id=${id}`)
			.then(res => {
				if (res.success) {
					$('#messageIdInput').val(id);
					$('#messageSubjectInput').val(res.data.subject);
					$('#messageEmailInput').val(res.data.email);
					$('#messageContentInput').val(res.data.message);
				} else {
					toastr.error(res.errMsg);
				}
			})
			.catch(err => {
				toastr.error(err.errMsg);
			})
	}

	this.saveMessage = function() {
		const currentId = $('#messageIdInput').val();
		const payload = {
			'subject': $('#messageSubjectInput').val(),
			'email': $('#messageEmailInput').val(),
			'message': $('#messageContentInput').val()
		};

		const apiCall = currentId ? Http.put(`${domain}/admin/api/messages?id=${currentId}`, payload) : Http.post(`${domain}/admin/api/messages`, payload);

		apiCall
			.then(res => {
				if (res.success) {
					toggleView(true);
					toastr.success(currentId ? 'Message updated successfully!' : 'Message created successfully!');
				} else {
					toastr.error(res.errMsg);
				}
			})
			.catch(err => {
				toastr.error(err.errMsg);
			});
	}

	this.draftMessage = function() {
		alert("Draft feature is not implemented yet.");
	}

	this.initSelect2Category = function() {
		$('#messageCategorySelect').select2({
			theme: 'bootstrap4',
			ajax: {
				url: `${domain}/admin/api/category`,
				headers: {
					'Authorization': 'Bearer ' + Http.getToken(),
					'Content-Type': 'application/json'
				},
				data: function(params) {
					return {
						type: 'filter',
						page: 0,
						size: 10,
						name: params.term
					};
				},
				processResults: function(res) {
					return {
						results: res.data.records.map(elm => ({
							id: elm.id,
							text: elm.name
						}))
					};
				}
			}
		});
	}

	this.toggleView = function(showTable, id = null) {
		if (showTable) {
			$('#messages-table').show();
			$('#messages-form').hide();
			fetchMessages(0, defaultPageSize);
		} else {
			$('#messages-table').hide();
			$('#messages-form').show();
			if (id == null) {
				$('#messageIdInput').val('');
				$('#messageSubjectInput').val('');
				$('#messageEmailInput').val('');
				$('#messageContentInput').val('');
			} else {
				getMessageById(id);
			}
		}
	}

	toggleView(true);
});
