<script src="${pageContext.request.contextPath}/page-admin/features/settings/index.js"></script>

<script>
	$(document).ready(function() {
	const $pagination = $('#postsPagination');
	let searchPostName = '';

	$pagination.twbsPagination(defaultOpts);

	this.searchPostsByName = function() {
	searchPostName = $('#inpSearchPostsName').val();
	this.fetchPosts(0, defaultPageSize, searchPostName);
}

	this.fetchPosts = function(page = 0, size = defaultPageSize, name = '') {
	Http.get(`${domain}/admin/api/settings?type=filter&page=${page}&size=${size}&name=${name}`)
	.then(res => {
	$('#tblPosts').empty();
	$pagination.twbsPagination('destroy');

	if (!res.success || res.data.totalRecord === 0) {
	$('#tblPosts').append(`<tr><td colspan='9' style='text-align: center;'>No Data</td></tr>`);
	return;
}

	let tableContent = '';
	res.data.records.forEach(record => {
	tableContent += `<tr>
                        <td>${record.id}</td>
                        <td>${record.type}</td>
                        <td>${record.image}</td>
                        <td><span class='badge ${record.status.toLowerCase() === 'active' ? 'bg-success' : 'bg-danger'}'>${record.status}</span></td>
                        <td>${record.updatedBy}</td>
                        <td>${record.updatedDate}</td>
                        <td class='text-right'>
                            <a class='btn btn-info btn-sm' onclick='togglePostView(false, ${record.id})'><i class='fas fa-pencil-alt'></i></a>
                            <a class='btn btn-danger btn-sm' onclick='deletePost(${record.id})'><i class='fas fa-trash'></i></a>
                        </td>
                    </tr>`;
});

	$pagination.twbsPagination($.extend({}, defaultOpts, {
	startPage: res.data.page + 1,
	totalPages: Math.ceil(res.data.totalRecord / res.data.size)
})).on('page', (event, num) => {
	this.fetchPosts(num - 1, defaultPageSize, searchPostName);
});

	$('#tblPosts').append(tableContent);
})
	.catch(err => {
	toastr.error(err.errMsg);
});
}

	this.deletePost = function(id) {
	if (confirm("Are you sure?")) {
	Http.delete(`${domain}/admin/api/settings?id=${id}`)
	.then(res => {
	if (res.success) {
	this.togglePostView(true);
	toastr.success('Delete settings success!');
} else {
	toastr.error(res.errMsg);
}
})
	.catch(err => {
	toastr.error(err.errMsg);
});
} else {
	toastr.info('Canceled delete settings');
}
}

	this.getPostById = function(id) {
	Http.get(`${domain}/admin/api/settings?type=getOne&id=${id}`)
	.then(res => {
	if (res.success) {
	$('#inpPostsId').val(id);
	$('#inpPostsBanner').val(null);
	$('#inpPostsTitle').val(res.data.type);
	$('#inpPostContent').summernote('code', res.data.content);
} else {
	toastr.error(res.errMsg);
}
})
	.catch(err => {
	toastr.error(err.errMsg);
});
}

	this.savePost = function() {
	const postId = $('#inpPostsId').val();
	const payload = {
	'type': $('#inpPostsTitle').val(),
	'content': $('#inpPostContent').summernote('code')
}

	let formData = new FormData();
	if ($('#inpPostsBanner')[0]) {
	formData.append('image', $('#inpPostsBanner')[0].files[0]);
}
	formData.append('payload', JSON.stringify(payload));

	if (postId) {
	Http.putFormData(`${domain}/admin/api/settings?id=${postId}`, formData)
	.then(res => {
	if (res.success) {
	this.togglePostView(true);
	toastr.success(`Update posts success!`);
} else {
	toastr.error(res.errMsg);
}
})
	.catch(err => {
	toastr.error(err.errMsg);
});
} else {
	Http.postFormData(`${domain}/admin/api/settings`, formData)
	.then(res => {
	if (res.success) {
	this.togglePostView(true);
	toastr.success(`Create posts success!`);
} else {
	toastr.error(res.errMsg);
}
})
	.catch(err => {
	toastr.error(err.errMsg);
});
}
}

	this.draftPost = function() {
	alert("Draft functionality not yet implemented.");
}

	this.initializeSelect2Category = function() {
	$('#selPostsCategory').select2({
	theme: 'bootstrap4',
	ajax: {
	url: `${domain}/admin/api/category`,
	headers: {
	'Authorization': 'Bearer ' + Http.getToken(),
	'Content-Type': 'application/json',
},
	data: function(params) {
	return {
	type: 'filter',
	page: 0,
	size: 10,
	name: params.term
};
},
	processResults: function(res) {
	return {
	results: res.data.records.map(elm => ({
	id: elm.id,
	text: elm.name
}))
};
}
}
});
}

	this.togglePostView = function(isTableVisible, id = null) {
	if (isTableVisible) {
	$('#posts-table').show();
	$('#posts-form').hide();
	this.fetchPosts(0, defaultPageSize);
} else {
	$('#inpPostContent').summernote({
	height: 150
});
	this.initializeSelect2Category();
	$('#posts-table').hide();
	$('#posts-form').show();
	if (id == null) {
	$('#inpPostsTitle').val(null);
	$('#inpPostsBanner').val(null);
	$('#inpPostContent').summernote('code', '');
} else {
	this.getPostById(id);
}
}
}

	$('#inpPostsBanner').change(function(e) {
	if (e.target.files.length) {
	$(this).next('.custom-file-label').html(e.target.files[0].name);
}
});

	this.togglePostView(true);
});
</script>