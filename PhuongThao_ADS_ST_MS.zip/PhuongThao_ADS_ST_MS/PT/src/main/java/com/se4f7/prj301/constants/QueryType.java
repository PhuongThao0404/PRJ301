package com.se4f7.prj301.constants;

public class QueryType {
	public final static String FILTER = "filter";
	public final static String GET_ONE = "getOne";
}
